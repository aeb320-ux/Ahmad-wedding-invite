دعوة زفاف أحمد وشذى — نسخة الأغنية

تم استبدال صوت الأجواء بأغنية الزفة المرفقة.

الملفات:
- index.html
- invitation.jpg
- wedding_song.mp3

للتحديث على GitHub Pages: ارفع الملفات الجديدة إلى المستودع واستبدل index.html، ثم ارفع wedding_song.mp3، واحذف celebration_ambience.wav إذا لم تعد تحتاجه.
